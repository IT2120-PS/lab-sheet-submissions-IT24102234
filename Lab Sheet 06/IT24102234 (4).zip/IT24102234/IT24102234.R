setwd("C:\\Users\\lap.lk\\Desktop\\IT24102234")

#Q1

n <- 50
p <- 0.85

#i
#binomial(n=50 and p=0.85)

#ii
#P(X>=47)
1-pbinom(46,n,p)

#Q2
#i
#X = No of customer calls received per hour

#ii
#lambda=12

#iii
lambda<-12
dpois(15, lambda)

